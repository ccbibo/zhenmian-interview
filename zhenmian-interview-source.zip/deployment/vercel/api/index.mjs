import worker from '../worker.mjs';

// Official Web Standard Vercel Node.js handler. No long-lived credentials in source.
// Production deployment protection must be enabled before confirming the host.
export function createVercelHandler(env,dispatcher=worker){
 return async function handle(request){
  const original=new URL(request.url),path=original.searchParams.get('__path');
  if(path===null||path.length>2048||!path.startsWith('/')||path.startsWith('//')||/[\\\u0000-\u001f]/u.test(path))return new Response('Not found',{status:404});
  const target=new URL(original);target.pathname=path;target.searchParams.delete('__path');
  if(target.pathname.startsWith('/api/')&&env.APP_PRIVATE_HOST_CONFIRMED!=='true'){
   const body=target.pathname==='/api/status'?{configured:false,llmConfigured:false,liveVerified:false,maxCallSeconds:120,message:'測試網站尚未開放，請稍後再試。'}:{error:'private_host_not_confirmed',message:'測試網站尚未開放，請稍後再試。'};
   return Response.json(body,{status:target.pathname==='/api/status'?200:503,headers:{'Cache-Control':'no-store'}});
  }
  const forwarded=new Request(target,request);
  // This header is trusted only on Sites, never from a Vercel visitor.
  forwarded.headers.delete('oai-authenticated-user-id');
  return dispatcher.fetch(forwarded,env,{});
 };
}
export default {fetch(request){return createVercelHandler(process.env)(request);}};
