import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { composeWorker } from "./compose.mjs";

const projectRoot = resolve(fileURLToPath(new URL("..", import.meta.url)));
const workerPath = resolve(projectRoot, "dist/server/index.js");
const manifestPath = resolve(projectRoot, "dist/.openai/hosting.json");

const [source, manifest] = await Promise.all([
  readFile(workerPath, "utf8"),
  readFile(manifestPath, "utf8"),
]);
const hosting = JSON.parse(manifest);
assert.equal(typeof hosting.project_id, "string", "Hosting manifest must retain the registered project_id");
assert.ok(hosting.project_id.trim(), "Hosting project_id cannot be empty");
assert.equal(source, await composeWorker(), "Built Worker differs from current sources; run the build again");

// A data URL forces ESM parsing even though the generated output has no package.json.
const moduleUrl = `data:text/javascript;base64,${Buffer.from(source).toString("base64")}`;
const workerModule = await import(moduleUrl);
assert.equal(
  typeof workerModule.default?.fetch,
  "function",
  `${pathToFileURL(workerPath)} must export default.fetch`,
);
const statusResponse = await workerModule.default.fetch(new Request("https://artifact.invalid/api/status"), {});
assert.equal(statusResponse.status, 200, "Built Worker status route must execute without credentials");
const status = await statusResponse.json();
assert.equal(status.configured, false);
assert.equal(status.liveVerified, false);

console.log("Artifact matches current sources, retains Site identity and executes its status route");
