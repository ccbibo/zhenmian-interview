import {access,copyFile,mkdir} from 'node:fs/promises';
import {dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

// Explicit product-source allowlist. Never copy environment files, credentials,
// repository metadata, private notes or evidence archives into the Site repo.
export const sourceFiles=[
 'public/index.html','public/style.css','public/home.css','public/ios-polish.css','public/app.js','public/home.js','public/document-import.js',
 'lib/interview.mjs','server.mjs','research/trial/jd.json','research/trial/resume.txt'
];
const parent=new URL('../../',import.meta.url),snapshot=new URL('../source/',import.meta.url);
export async function syncSource(){
 let parentPresent=false;
 try{await access(new URL('public/index.html',parent));parentPresent=true;}catch{}
 if(parentPresent){
  // Readability checks finish before copying so partial parent trees fail visibly.
  await Promise.all(sourceFiles.map(name=>access(new URL(name,parent))));
  for(const name of sourceFiles){const target=new URL(name,snapshot);await mkdir(dirname(fileURLToPath(target)),{recursive:true});await copyFile(new URL(name,parent),target);}
 }else{
  await Promise.all(sourceFiles.map(name=>access(new URL(name,snapshot))));
 }
 return {mode:parentPresent?'workspace_source':'repository_snapshot',files:sourceFiles.length};
}
if(typeof process!=='undefined'&&process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)console.log(JSON.stringify(await syncSource()));
