// Hosted runtime. Bundled with shared validators, model client and static assets.
const leases = new Map(); // Owner-private trial only: isolate-local, never a distributed lock.
const reportPending=new Set(),reportCache=new Map();
const REPORT_TTL_MS=600000,REPORT_CACHE_LIMIT=10,REPORT_CACHE_MAX_BYTES=262144;
function pruneReportCache(){const now=Date.now();for(const [key,item] of reportCache)if(item.expires<=now)reportCache.delete(key);}
async function reportVersion(history){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(history)));return [...new Uint8Array(bytes)].map(value=>value.toString(16).padStart(2,'0')).join('');}
function rememberReport(key,result){pruneReportCache();if(new TextEncoder().encode(JSON.stringify(result)).length>REPORT_CACHE_MAX_BYTES)return;while(reportCache.size>=REPORT_CACHE_LIMIT)reportCache.delete(reportCache.keys().next().value);reportCache.set(key,{result,expires:Date.now()+REPORT_TTL_MS});}
const cookieName='opposite_room';
const jsonResponse=(status,data,extra={})=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',...extra}});
function readCookies(req){return Object.fromEntries((req.headers.get('cookie')||'').split(';').map(s=>s.trim().split(/=(.*)/s)).filter(p=>p.length>=2).map(([k,v])=>[k,v]));}
async function cryptoKey(env){if(!env.SESSION_SECRET||env.SESSION_SECRET.length<32)throw new Fault(503,'session_not_configured','尚未設定安全會話服務。');return crypto.subtle.importKey('raw',await crypto.subtle.digest('SHA-256',new TextEncoder().encode(env.SESSION_SECRET)),'AES-GCM',false,['encrypt','decrypt']);}
async function sealClaim(claim,env){const iv=crypto.getRandomValues(new Uint8Array(12));const encrypted=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},await cryptoKey(env),new TextEncoder().encode(JSON.stringify(claim))));const encoded=btoa(String.fromCharCode(...iv,...encrypted)).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');if(encoded.length>3600)throw new Fault(502,'session_cookie_too_large','安全入場憑證過大，已停止入場並嘗試結束會話。');return encoded;}
async function readClaim(req,env,owner){const encoded=readCookies(req)[cookieName];if(!encoded)return null;try{const raw=Uint8Array.from(atob(encoded.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0));const text=await crypto.subtle.decrypt({name:'AES-GCM',iv:raw.slice(0,12)},await cryptoKey(env),raw.slice(12));const claim=JSON.parse(new TextDecoder().decode(text));if(claim.owner!==owner||claim.expires<Date.now())return null;return claim;}catch{return null;}}
const sessionCookie=value=>`${cookieName}=${value}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=86400`;
async function bodyJSON(request){if(!(request.headers.get('Content-Type')||'').startsWith('application/json'))throw new Fault(415,'json_required','請使用JSON格式。');const reader=request.body?.getReader();let size=0;const chunks=[];if(reader){while(true){const {value,done}=await reader.read();if(done)break;size+=value.length;if(size>128*1024){await reader.cancel();throw new Fault(413,'payload_too_large','資料總量超過128KB，請縮短內容。');}chunks.push(value);}}const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}try{const data=JSON.parse(new TextDecoder().decode(bytes));if(!data||typeof data!=='object'||Array.isArray(data))throw Error();return data;}catch{throw new Fault(400,'invalid_json','無法讀取輸入內容。');}}
async function tavusRequest(env,path='',payload,method='POST'){let response;try{response=await fetch(`https://tavusapi.com/v2/conversations${path}`,{method,redirect:'error',headers:{'x-api-key':env.TAVUS_API_KEY.trim(),'Content-Type':'application/json'},...(payload?{body:JSON.stringify(payload)}:{}),signal:AbortSignal.timeout(20000)});}catch{throw new Fault(502,'upstream_unknown','建立或結束的結果不明，請先到Tavus後台確認，不要重複開始。');}if(!response.ok)throw new Fault(503,'upstream_rejected',`即時服務未接受請求（${response.status}），請檢查額度與設定。`);if(method==='POST'&&path.endsWith('/end'))return {};try{return await response.json();}catch{throw new Fault(502,'upstream_unknown','外部服務回覆無法辨識，請先確認後台狀態。');}}
function activeClaim(claim){return Boolean(claim&&claim.state!=='ended');}
async function endClaim(claim,env){
 if(claim.state==='ended')return;
 if(!claim.upstreamId)throw new Fault(409,'creation_unknown','建立結果不明，請先從Tavus後台確認。');
 try{await tavusRequest(env,`/${encodeURIComponent(claim.upstreamId)}/end`);claim.state='ended';claim.endedAt=new Date().toISOString();delete claim.conversationUrl;}
 catch(error){claim.state='end_failed';throw error;}
}
async function reconcileClaim(claim,env){
 if(!claim.upstreamId)throw new Fault(409,'creation_unknown','建立結果不明，請先從Tavus後台確認。');
 if(claim.state==='ended')return;
 const result=await tavusRequest(env,`/${encodeURIComponent(claim.upstreamId)}`,undefined,'GET');
 if(result.conversation_id!==claim.upstreamId)throw new Fault(502,'upstream_mismatch','即時服務回傳的會話識別不符。');
 if(result.status==='ended'){claim.state='ended';claim.endedAt=new Date().toISOString();delete claim.conversationUrl;}
 else if(result.status!=='active')throw new Fault(502,'upstream_state_unknown','即時服務會話狀態尚無法確認。');
}
export default {
 async fetch(request,env={},ctx={}){
  const url=new URL(request.url), path=url.pathname;
  try{
   if(path.startsWith('/api/')){
    if(!['GET','POST'].includes(request.method))throw new Fault(405,'method_not_allowed','不支援此操作。');
    const origin=request.headers.get('Origin');
    if(request.headers.get('Sec-Fetch-Site')==='cross-site'||(origin&&origin!==url.origin))throw new Fault(403,'origin_rejected','僅允許網站同來源操作。');
    // Sites supplies authenticated identity for visitors. Owner-private access also gates service requests.
    const cookies=readCookies(request);let owner=cookies.opposite_owner;
    const identity=request.headers.get('oai-authenticated-user-id');
    if(identity)owner=`user:${identity}`;
    let ownerCookie=null;
    if(!owner||(!identity&&!/^[a-f0-9-]{36}$/.test(owner))){owner=crypto.randomUUID();ownerCookie=`opposite_owner=${owner}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=86400`;}
    const respond=(status,data,headers={})=>{const response=jsonResponse(status,data,headers);if(ownerCookie)response.headers.append('Set-Cookie',ownerCookie);return response;};
    const missingConfiguration=['TAVUS_API_KEY','TAVUS_PAL_ID'].filter(key=>typeof env[key]!=='string'||!env[key].trim());
    if(typeof env.SESSION_SECRET!=='string'||env.SESSION_SECRET.length<32)missingConfiguration.push('SESSION_SECRET');
    let maxCallSeconds=null,callLimitError=null;
    try{maxCallSeconds=effectiveCallSeconds(45,env);}catch(error){callLimitError=error.code;}
    let faceMapError=null;try{parseFaceMap(env);}catch(error){faceMapError=error.code;}
    const configError=callLimitError||faceMapError;
    const configured=missingConfiguration.length===0&&!configError;
    const llm=modelConfigurationStatus(env),llmReady=llm.configured;
    if(request.method==='GET'&&path==='/api/status'){
     const claim=await readClaim(request,env,owner);
     return respond(200,{configured,provider:'tavus',reportConfigured:llmReady,llmConfigured:llmReady,llmConfigurationError:llm.error,maxCallSeconds,callLimitError,faceMapError,configError,missingConfiguration,singleAvatarOnly:true,liveVerified:false,activeSession:activeClaim(claim),activeSessionId:activeClaim(claim)?claim.sessionId:null,lastSessionId:claim?.sessionId||null,state:claim?.state||null,cleanupPending:claim?.state==='end_failed',requiresProviderCheck:claim?.state==='creation_unknown',storageMode:'encrypted_browser_session',deploymentScope:'owner_private_trial',distributedSessionLock:false,message:configError?'通話或人物對應設定無效，不能開始面試。':configured?'憑證已設定；真人影音仍待實測。':'真人影音服務尚未連接，不能開始真實視訊面試。'});
    }
    if(request.method==='GET'&&path==='/api/trial')return respond(200,TRIAL);
    if(request.method==='POST'&&path==='/api/analyze'){const data=await bodyJSON(request);return respond(200,parseEvidence(data.jd,data.resume));}
    if(request.method==='POST'&&(path==='/api/question'||path==='/api/report')){
     const data=await bodyJSON(request);if(data.consent!==true)throw new Fault(400,'consent_required','請先同意將本次資料傳送至模型服務。');
     const input={...data,signal:request.signal};
     const result=path==='/api/question'?await generateQuestion(input,env):await generateReport(input,env);
     return respond(200,result);
    }
    if(request.method==='POST'&&path==='/api/session'){
     const sessionData=await bodyJSON(request),input=validateSession(sessionData);
     input.durationMinutes=effectiveCallSeconds(input.durationMinutes,env)/60;
     if(faceMapError)throw new Fault(503,faceMapError,'人物對應設定無效，不能開始面試。');
     if(!configured)throw new Fault(503,'provider_not_configured','尚未開通寫實人物API，請先完成服務設定。');
     // Fail before creating a billable room if the recovery token cannot be encrypted.
     await cryptoKey(env);
     let continuation=null;
     if(sessionData.continuation!==undefined){
      if(!sessionData.continuation||typeof sessionData.continuation!=='object'||Array.isArray(sessionData.continuation)||typeof sessionData.continuation.receipt!=='string')throw new Fault(400,'invalid_continuation','續接憑證格式不正確。');
      continuation=await verifyAndLoadRoundContinuation({owner,jd:input.jd,resume:input.resume,round:input.round,receipt:sessionData.continuation.receipt},env,globalThis.fetch,{signal:request.signal});
      input.priorRounds=continuation.priorRounds;
     }
     const originalDocumentHash=await documentFingerprint(input.jd,input.resume);
     if(activeClaim(await readClaim(request,env,owner))||leases.has(owner))throw new Fault(409,'session_exists','已有尚未確認結束的會話，請先結束或到服務後台確認。');
     const claim={owner,sessionId:crypto.randomUUID(),state:'creation_unknown',expires:Date.now()+86400000,createdAt:new Date().toISOString(),durationMinutes:input.durationMinutes,documentHash:originalDocumentHash,settings:{round:input.round,interviewType:input.interviewType,focusTopics:input.focusTopics,role:input.role},lineage:continuation?.lineage||[],continuationExpiresAt:continuation?.expiresAt||null};leases.set(owner,Date.now());
     try{
      const mapping=parseFaceMap(env);
      const face=mapping[input.role.id]||env.TAVUS_FACE_ID;
      const result=await tavusRequest(env,'',{pal_id:env.TAVUS_PAL_ID.trim(),...(face?{face_id:face}:{}),conversational_context:buildContext(input),custom_greeting:buildGreeting(input),require_auth:true,max_participants:2,participant_tags:[],properties:{max_call_duration:input.durationMinutes*60,enable_recording:false}});
      if(typeof result.conversation_id!=='string'||!/^[a-zA-Z0-9_-]{1,100}$/.test(result.conversation_id))throw new Fault(502,'upstream_unknown','會話結果不明，請先在Tavus後台確認。');
      claim.upstreamId=result.conversation_id;claim.state='created';
      let join;
      try{join=new URL(result.conversation_url);if(join.protocol!=='https:'||!(join.hostname==='daily.co'||join.hostname.endsWith('.daily.co'))||join.username||join.password||typeof result.meeting_token!=='string'||!result.meeting_token)throw Error();}
      catch{try{await tavusRequest(env,`/${encodeURIComponent(claim.upstreamId)}/end`);claim.state='ended';}catch{claim.state='end_failed';}throw new Fault(502,'invalid_join_response','人物服務入場連結無法驗證，請確認會話已結束。');}
      if(result.meeting_token.length>2500)throw new Fault(502,'session_cookie_too_large','安全入場憑證過大，已停止入場。');
      join.searchParams.set('t',result.meeting_token);claim.conversationUrl=join.href;
      return respond(201,{sessionId:claim.sessionId,conversationUrl:join.href,liveVerified:false,avatarMapping:mapping[input.role.id]?'role_mapped':'default_face',durationMinutes:input.durationMinutes,continuationUsed:Boolean(continuation),priorRoundCount:continuation?.priorRounds.length||0,notice:mapping[input.role.id]?'人物對應已設定，仍需實測。':'目前使用服務預設人物，尚未對應專屬角色形象。'},{'Set-Cookie':sessionCookie(await sealClaim(claim,env))});
     }catch(error){const headers={};if(claim.upstreamId&&claim.state==='created'){try{await endClaim(claim,env);}catch{}}delete claim.conversationUrl;if(error.code==='upstream_unknown'||claim.upstreamId||claim.state==='end_failed'){headers['Set-Cookie']=sessionCookie(await sealClaim(claim,env));}return respond(error.status||500,{error:error.code||'internal_error',message:error.message||'建立失敗。'},headers);}
     finally{leases.delete(owner);}
    }
    if(request.method==='POST'&&path==='/api/session/end'){
     const data=await bodyJSON(request),claim=await readClaim(request,env,owner);
     if(!claim||data.sessionId!==claim.sessionId)throw new Fault(404,'session_not_found','找不到本瀏覽器的會話。');
     try{await endClaim(claim,env);}catch(error){return respond(error.status||502,{error:error.code,message:error.message},{'Set-Cookie':sessionCookie(await sealClaim(claim,env))});}
     return respond(200,{sessionId:claim.sessionId,state:'ended'},{'Set-Cookie':sessionCookie(await sealClaim(claim,env))});
    }
    const sessionMatch=path.match(/^\/api\/session\/([a-zA-Z0-9_-]{1,100})(?:\/(transcript|report|continuation))?$/);
    if(sessionMatch){
     const [,id,action]=sessionMatch,claim=await readClaim(request,env,owner);
     if(!claim||id!==claim.sessionId)throw new Fault(404,'session_not_found','找不到本瀏覽器的會話。');
     if(request.method==='GET'&&!action){
      await reconcileClaim(claim,env);
      return respond(200,{sessionId:claim.sessionId,state:claim.state,durationMinutes:claim.durationMinutes,createdAt:claim.createdAt,endedAt:claim.endedAt||null,...(claim.state==='created'&&claim.conversationUrl?{conversationUrl:claim.conversationUrl}:{}),liveVerified:false},{'Set-Cookie':sessionCookie(await sealClaim(claim,env))});
     }
     if(request.method==='POST'&&action==='continuation'){
      await bodyJSON(request);
      await reconcileClaim(claim,env);
      if(claim.state!=='ended')throw new Fault(409,'session_not_ended','請先結束本輪面試，再接續下一輪。');
      if(!claim.documentHash||!claim.settings)throw new Fault(409,'session_context_unavailable','此舊會話缺少文件版本資訊，不能可靠續接。');
      if(!['1','2'].includes(claim.settings.round))throw new Fault(409,'rounds_complete','本系列已完成第三輪，沒有下一輪可續接。');
      const transcript=await getConversationTranscript(claim.upstreamId,env,globalThis.fetch,{signal:request.signal});
      if(transcript.state!=='ready'||!transcript.history.some(turn=>turn.role==='candidate'))throw new Fault(409,transcript.state==='pending'?'transcript_pending':'insufficient_answers','尚無可用的候選人最終逐字稿，不能續接。');
      const lineage=[...(claim.lineage||[]),{round:claim.settings.round,sessionId:claim.sessionId,upstreamId:claim.upstreamId,transcriptHash:await transcriptFingerprint(transcript.history),role:claim.settings.role,interviewType:claim.settings.interviewType,focusTopics:claim.settings.focusTopics}];
      const issued=await issueRoundContinuation({owner,documentHash:claim.documentHash,lineage,expiresAt:Math.min(claim.expires,claim.continuationExpiresAt||claim.expires)},env);
      return respond(200,{...issued,notice:'已準備下一輪。按下開始才建立新會話，每場仍依測試上限執行。'},{'Set-Cookie':sessionCookie(await sealClaim(claim,env))});
     }
     if((request.method==='GET'&&action==='transcript')||(request.method==='POST'&&action==='report')){
      await reconcileClaim(claim,env);
      if(claim.state!=='ended')throw new Fault(409,'session_not_ended','請先結束面試，再讀取逐字稿與回饋。');
      const headers={'Set-Cookie':sessionCookie(await sealClaim(claim,env))};
      if(action==='transcript')return respond(200,{...await getConversationTranscript(claim.upstreamId,env,globalThis.fetch,{signal:request.signal}),round:claim.settings?.round||null},headers);
      const data=await bodyJSON(request);
      if(data.consent!==true)throw new Fault(400,'consent_required','請先同意將實際逐字稿與文件傳送至模型服務。');
      const jd=text(data.jd,'JD',20),resume=text(data.resume,'履歷',20);
      if(!claim.documentHash||!claim.settings)throw new Fault(409,'session_context_unavailable','此舊會話缺少文件版本資訊，無法產生可靠回饋。');
      if(await documentFingerprint(jd,resume)!==claim.documentHash)throw new Fault(409,'documents_changed','JD 或履歷已更改，請還原本場文件後再產生回饋。');
      const reportOwnerKey=JSON.stringify([owner,claim.sessionId]);
      if(reportPending.has(reportOwnerKey))throw new Fault(409,'report_in_progress','本場回饋正在產生，請等待原請求完成。');
      if(reportPending.size>=32)throw new Fault(503,'report_capacity','回饋服務暫時忙碌，請稍後再試。');
      reportPending.add(reportOwnerKey);
      try{
       const transcript=await getConversationTranscript(claim.upstreamId,env,globalThis.fetch,{signal:request.signal});
       if(transcript.state!=='ready')throw new Fault(409,transcript.state==='pending'?'transcript_pending':'insufficient_answers',transcript.notice);
       const cacheKey=JSON.stringify([owner,claim.sessionId,claim.documentHash,await reportVersion(transcript.history),env.LLM_BASE_URL||'',env.LLM_MODEL||'']);
       pruneReportCache();const cached=reportCache.get(cacheKey);
       if(cached)return respond(200,{...cached.result,cached:true},headers);
       const result={...await generateReport({jd,resume,...claim.settings,history:transcript.history,signal:request.signal},env),source:'tavus_transcript',liveVerified:false};
       rememberReport(cacheKey,result);
       return respond(200,{...result,cached:false},headers);
      }finally{reportPending.delete(reportOwnerKey);}
     }
     throw new Fault(405,'method_not_allowed','不支援此會話操作。');
    }
    throw new Fault(404,'not_found','找不到此功能。');
   }
   if(!['GET','HEAD'].includes(request.method))throw new Fault(405,'method_not_allowed','不支援此操作。');
   const asset=ASSETS[path==='/'?'/index.html':path];
   if(!asset)return jsonResponse(404,{message:'找不到頁面。'});
   return new Response(request.method==='HEAD'?null:asset.text,{headers:{'Content-Type':asset.type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Permissions-Policy':'camera=(self "https://*.daily.co"), microphone=(self "https://*.daily.co")'}});
  }catch(error){return jsonResponse(error instanceof Fault||error instanceof InterviewError?error.status:500,{error:error.code||'internal_error',message:error instanceof Fault||error instanceof InterviewError?error.message:'服務暫時無法處理，請稍後重試。'});}
 }
};
