import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,readFile,writeFile,stat,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {parseEnv} from 'node:util';
import {createLocalSettings,settingsSnapshot,checkLocalSettings,resolveTavusSettings} from '../lib/local-settings.mjs';
async function fixture(t){const dir=await mkdtemp(join(tmpdir(),'zhenmian-settings-'));t.after(()=>rm(dir,{recursive:true,force:true}));return {path:join(dir,'.env'),dir};}
test('settings persist privately, preserve unrelated configuration and never return credentials',async t=>{
 const f=await fixture(t);await writeFile(f.path,'# private settings\nPORT=4180\nSESSION_SECRET=fixture-session-secret\nexport LLM_API_KEY=old-fixture\nLLM_API_KEY=duplicate-fixture\nTAVUS_MAX_CALL_SECONDS=2700\n');
 const env={LLM_API_KEY:'old-fixture',TAVUS_API_KEY:'old-tavus-fixture'};
 const saved=await createLocalSettings(f.path).save(env,{deepseekKey:'new-deepseek-fixture',tavusKey:'new-tavus-fixture',model:'deepseek-flash',palId:'p_fixture',faceId:''});
 const text=await readFile(f.path,'utf8'),parsed=parseEnv(text);
 assert.equal(parsed.LLM_API_KEY,'new-deepseek-fixture');assert.equal(parsed.TAVUS_API_KEY,'new-tavus-fixture');
 assert.equal(parsed.SESSION_SECRET,'fixture-session-secret');assert.equal(parsed.TAVUS_MAX_CALL_SECONDS,'2700');assert.equal(parsed.PORT,'4180');
 assert.equal(text.match(/^LLM_API_KEY=/gm).length,1);assert.equal((await stat(f.path)).mode&0o777,0o600);
 assert.equal(saved.deepseekKeySet,true);assert.equal(saved.tavusKeySet,true);assert.doesNotMatch(JSON.stringify(saved),/new-deepseek-fixture|new-tavus-fixture/);
 await createLocalSettings(f.path).save(env,{deepseekKey:'',tavusKey:'',model:'deepseek-flash',palId:'p_changed',faceId:'f_fixture'});
 assert.equal(env.LLM_API_KEY,'new-deepseek-fixture');assert.equal(parseEnv(await readFile(f.path,'utf8')).TAVUS_API_KEY,'new-tavus-fixture');
});
test('invalid input cannot inject environment variables or mutate stored configuration',async t=>{
 const f=await fixture(t);const env={};const settings=createLocalSettings(f.path);
 for(const data of [{deepseekKey:'key\nPORT=9999'},{deepseekKey:'key#suffix'},{palId:'../private'},{LLM_BASE_URL:'https://evil.example'},{model:''},{tavusKey:42}])await assert.rejects(()=>settings.save(env,data));
 assert.deepEqual(env,{});await assert.rejects(()=>stat(f.path),{code:'ENOENT'});
});
test('failed persistence never applies credentials to runtime',async t=>{
 const f=await fixture(t);const env={LLM_API_KEY:'old-fixture'};
 await assert.rejects(()=>createLocalSettings(join(f.dir,'missing','.env')).save(env,{deepseekKey:'new-fixture'}));assert.equal(env.LLM_API_KEY,'old-fixture');
});
test('provider checks use only fixed read-only endpoints and discard private PAL contents',async()=>{
 const env={LLM_API_KEY:'deepseek-private-fixture',LLM_MODEL:'deepseek-flash',TAVUS_API_KEY:'tavus-private-fixture',TAVUS_PAL_ID:'p_fixture'};
 const calls=[];const result=await checkLocalSettings(env,async(url,options)=>{
 calls.push({url,options});assert.equal(options.method,'GET');assert.equal(options.redirect,'error');assert.equal(options.body,undefined);
 return Response.json(url.includes('deepseek')?{data:[{id:'deepseek-flash'}]}:{pal_id:'p_fixture',default_face_id:'f_fixture',layers:{llm:{api_key:'provider-hidden-fixture'}}});
 });
 assert.equal(result.deepseek.ok,true);assert.equal(result.tavus.ok,true);assert.equal(result.liveInterviewVerified,false);
 assert.deepEqual(calls.map(x=>x.url),['https://api.deepseek.com/models','https://tavusapi.com/v2/pals/p_fixture']);
 assert.doesNotMatch(JSON.stringify(result),/private-fixture|provider-hidden/);
});
test('checks distinguish missing configuration, rejection, missing face and malformed responses',async()=>{
 let calls=0;const missing=await checkLocalSettings({},async()=>{calls++});assert.equal(calls,0);assert.equal(missing.tavus.ok,false);
 const env={LLM_API_KEY:'fixture',LLM_MODEL:'deepseek-flash',TAVUS_API_KEY:'fixture',TAVUS_PAL_ID:'p_fixture'};
 const rejected=await checkLocalSettings(env,async()=>new Response('sensitive-provider-error',{status:401}));assert.equal(rejected.deepseek.ok,false);assert.doesNotMatch(JSON.stringify(rejected),/sensitive-provider-error/);
 const wrong=await checkLocalSettings(env,async url=>Response.json(url.includes('deepseek')?{data:[{id:'different'}]}:{pal_id:'p_fixture'}));assert.equal(wrong.deepseek.ok,false);assert.equal(wrong.tavus.ok,false);
 const malformed=await checkLocalSettings(env,async()=>new Response('bad-json'));assert.equal(malformed.deepseek.ok,false);
 assert.deepEqual(Object.keys(settingsSnapshot(env)).sort(),['deepseekKeySet','faceId','model','palId','tavusKeySet'].sort());
});

test('API-only setup resolves an interview PAL without creating a call',async()=>{
 const calls=[];
 const result=await resolveTavusSettings({TAVUS_API_KEY:'fixture'},async(url,options)=>{
  calls.push(url);assert.equal(options.method,'GET');
  return Response.json({data:[{pal_id:'p_sales',pal_name:'Sales',default_face_id:'r_sales'},{pal_id:'p_interview',pal_name:'AI Interviewer',default_face_id:'r_interview'}]});
 });
 assert.equal(result.ok,true);assert.equal(result.palId,'p_interview');assert.equal(result.faceId,'r_interview');assert.equal(calls.length,1);
});
test('legacy name rejected with 400 resolves to its actual PAL ID',async()=>{
 const result=await resolveTavusSettings({TAVUS_API_KEY:'fixture',TAVUS_PAL_ID:'kevin'},async url=>
  url.endsWith('/kevin')?new Response('',{status:400}):Response.json({data:[{pal_id:'p_kevin',pal_name:'Kevin',default_face_id:'r_kevin'}]}));
 assert.equal(result.ok,true);assert.equal(result.palId,'p_kevin');
});
test('invalid key is reported without fallback, and empty accounts remain unready',async()=>{
 let calls=0;
 const invalid=await resolveTavusSettings({TAVUS_API_KEY:'fixture',TAVUS_PAL_ID:'p_old'},async()=>{calls++;return new Response('',{status:401});});
 assert.equal(invalid.ok,false);assert.equal(calls,1);
 const empty=await resolveTavusSettings({TAVUS_API_KEY:'fixture'},async()=>Response.json({data:[]}));
 assert.equal(empty.ok,false);assert.match(empty.message,/金鑰已通過驗證/);
});

test('PAL discovery handles large configurations and follows pagination',async()=>{
 const pages=[];
 const result=await resolveTavusSettings({TAVUS_API_KEY:'fixture'},async url=>{
  const page=Number(new URL(url).searchParams.get('page'));
  assert.equal(new URL(url).searchParams.get('limit'),'10');pages.push(page);
  return Response.json(page===1?{data:Array.from({length:10},(_,i)=>({pal_id:'p_other'+i,pal_name:'Other',default_face_id:'r_other',system_prompt:'x'.repeat(30000)})),total_count:11}:{data:[{pal_id:'p_interview',pal_name:'Interview',default_face_id:'r_interview'}],total_count:11});
 });
 assert.equal(result.ok,true);assert.deepEqual(pages,[1,2]);assert.equal(result.palId,'p_interview');
});
test('PAL diagnostics distinguish timeout, DNS, malformed and oversized replies',async()=>{
 const env={TAVUS_API_KEY:'fixture'};
 const cases=[
  [async()=>{throw new DOMException('private','TimeoutError')},'timeout'],
  [async()=>{throw Object.assign(new TypeError('private'),{cause:{code:'ENOTFOUND'}})},'dns_error'],
  [async()=>new Response('private non-JSON response'),'invalid_response'],
  [async()=>new Response('x'.repeat(1048577)),'response_too_large']
 ];
 for(const [fetchImpl,code] of cases){
  const result=await resolveTavusSettings(env,fetchImpl);
  assert.equal(result.ok,false);assert.equal(result.code,code);
  assert.doesNotMatch(JSON.stringify(result),/private|fixture/);
 }
});
