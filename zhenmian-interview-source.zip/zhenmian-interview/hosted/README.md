# 真面一下 — Hosted Worker

這是網頁版的 Cloudflare Worker 來源，使用 Node.js 22 以上的內建工具，不需要安裝 npm 套件。網站目前是否已發布，須以 Sites 原生部署結果為準；本機測試通過不代表已上線。

## 修改來源

- 網頁：上層 `public/`。
- 模型契約與通話上限：上層 `lib/interview.mjs`。
- 輸入驗證與面試提示：上層 `server.mjs`。
- Hosted 路由與會話：`worker/runtime.mjs`。

`worker/index.js` 與 `dist/` 都是產生的檔案，不要直接編輯。`scripts/sync-source.mjs` 以固定產品檔案清單同步到本 repo 的 `source/`，不複製 `.env`、秘密、私人筆記或證據檔。父專案存在時建置會同步最新來源；獨立 checkout 沒有父專案時，使用已提交的 `source/` 快照。`scripts/compose.mjs` 只讀 repo 內快照，整合網頁、共用邏輯及已標示虛構的測試履歷。

## 檢查與建置

在本資料夾執行：

```sh
npm test
npm run build
npm run validate
```

測試即時組合目前來源，在記憶體使用合成供應商回覆，不建立真實 Tavus 通話、不消耗通話額度。建置必定先重新組合來源，避免複製舊的 `worker/index.js`。

輸出只有 `dist/server/index.js` 與 `dist/.openai/hosting.json`。發布前必須推送完全相同的來源 commit，透過 Sites 儲存版本再部署；保留既有 project ID 和私人存取設定。

## Runtime 設定

在網站的秘密設定提供 `TAVUS_API_KEY`、`TAVUS_PAL_ID`、`SESSION_SECRET`（至少 32 字元）；視需要提供 `TAVUS_FACE_ID` 或 `TAVUS_FACE_MAP`。模型使用 `LLM_API_KEY`、`LLM_MODEL`、`LLM_BASE_URL`。DeepSeek 基址為 `https://api.deepseek.com`。秘密不寫入來源、manifest、建置產物或測試。

正常使用設定 `TAVUS_MAX_CALL_SECONDS=2700`（未設定時同樣預設 2700）；使用者選擇 15–45 分鐘、每 5 分鐘調整，實際時長會傳至影音服務並回傳前端。僅短場測試時明確設為 `120`。既有線上環境若仍設為 `120`，須更新為 `2700` 並重新部署；只更新原始碼不會覆蓋既有環境設定。非法上限會在建立通話前拒絕。

`GET /api/status` 只檢查設定格式，不驗證金鑰真偽；`liveVerified` 仍為 false。本版本只限 owner-private 的單人試驗。會話採 owner 綁定的加密 cookie 與 isolate 內的短暫防重複機制，不提供跨 isolate 的分散式鎖。Cookie 被清除、舊 claim 被重播或跨節點同時請求時，無法保證全域防重；這是正式發布給多人使用的硬性阻擋項目，不能以合成測試代替。

## 會話恢復與逐字稿

- `GET /api/session/:id`：僅持有原 owner cookie 者可讀；向 Tavus 確認原會話狀態，活躍時恢復原入場連結，不重建通話。
- `POST /api/session/end`：保留 ended claim，讓本瀏覽器之後仍可讀最後一場逐字稿。可重複結束已結束的會話，不再呼叫供應商。
- `GET /api/session/:id/transcript`：確認已結束後，讀 Tavus 最終逐字稿；只回對話文字，不回視覺分析或工具內容。
- `POST /api/session/:id/report`：傳 `{consent:true,jd,resume}`；文件須與建立時的 SHA256 版本相符，採用建立時設定及伺服器讀得的逐字稿，忽略呼叫端自造的 history。原始文件不放 cookie。

入場 token 只存在加密 claim 與傳給官方 Daily iframe 的入場 URL。API status 不回 token；我方 API query 不收 token。Claim 有大小限制，過大時會嘗試結束已建立的通話，清理失敗會保留可重試狀態。逐字稿可能尚未就緒或有辨識誤差，不能據此宣稱影音品質已通過驗證。

語音回饋在同一 isolate 以 owner＋session 防止並發重複模型呼叫；成功結果僅在私人記憶體快取 10 分鐘，最多 10 筆、每筆 256 KiB。快取鍵包含原文件與最終逐字稿版本，其他 owner 無法取用。這不提供跨 isolate 的防重與快取保證。

## 分輪續接

`POST /api/session/:id/continuation` 傳 `{}`：僅已結束且有候選人最終逐字稿的第一、二輪可取得 `{nextRound,receipt,expiresAt,notice}`。取得憑證不會建立新通話。下一場由使用者明確開始，在原 `/api/session` payload 加入 `continuation:{receipt}`，每輪依使用者所選時長，正常上限為 45 分鐘。

憑證使用 AES-GCM、用途隔離、owner／原文件摘要／前輪順序與最終逐字稿摘要綁定。伺服器會重新讀取最多兩輪真實 Tavus 逐字稿並核對版本，再傳入下一場上下文；不採用客戶端自造的前輪 history。第二輪保存前輪來源，因此第三輪可接續第一、二輪。續接鏈不延長最早來源的期限，第三輪不可再取得第四輪憑證。這些皆經合成測試，仍待真人影音實測與跨 isolate 持久防重。
