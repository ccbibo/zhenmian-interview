'use strict';
(()=>{
  const dialog=document.querySelector('#api-settings-dialog');
  const form=document.querySelector('#api-settings-form');
  if(!dialog||!form)return;
  const field=id=>form.querySelector('#'+id);
  const message=document.querySelector('#api-settings-message');
  const result=document.querySelector('#api-check-results');
  const check=document.querySelector('#api-settings-check');
  const checkLabel=check.textContent;
  let token='',busy=false,saved;
  function showCheckStatus(text){
    const line=document.createElement('p');
    line.textContent=text;
    result.replaceChildren(line);
    result.scrollIntoView({block:'nearest'});
  }
  async function request(path,body){
    const response=await fetch(path,{signal:AbortSignal.timeout(30000),method:body===undefined?'GET':'POST',credentials:'same-origin',headers:{'Content-Type':'application/json',...(body===undefined?{}:{'X-Settings-Token':token})},...(body===undefined?{}:{body:JSON.stringify(body)})});
    const data=await response.json().catch(()=>{throw new Error('本機服務未回傳設定資料，請確認已啟動真面一下。');});
    if(!response.ok)throw new Error(data.message||'無法完成設定，請稍後再試。');
    return data;
  }
  function clearSecrets(){field('settings-deepseek-key').value='';field('settings-tavus-key').value='';}
  function displayKey(provider,stored){
    const input=field('settings-'+provider+'-key');
    input.readOnly=stored;
    input.placeholder=stored?'••••••••　已儲存在本機':provider==='tavus'?'貼上 Tavus API Key':'貼上大模型 API Key';
    field('change-'+provider+'-key').hidden=!stored;
    field(provider+'-key-state').textContent=stored?'金鑰已儲存':'尚未設定';
  }
  for(const provider of ['deepseek','tavus']){
    field('change-'+provider+'-key').addEventListener('click',()=>{
      const input=field('settings-'+provider+'-key');
      input.readOnly=false;
      input.placeholder='貼上新金鑰，再按「儲存並套用」';
      field('change-'+provider+'-key').hidden=true;
      field(provider+'-key-state').textContent='儲存新金鑰前，繼續使用原金鑰';
      input.focus();
    });
  }
  function apply(data){
    saved=data;
    displayKey('deepseek',data.deepseekKeySet);
    displayKey('tavus',data.tavusKeySet);
    field('settings-model').value=data.model;
  }
  function lock(value){busy=value;form.querySelectorAll('input,button').forEach(el=>el.disabled=value);document.querySelector('#api-settings-close').disabled=value;}
  async function open(){
    if(busy)return;
    form.hidden=true;
    clearSecrets();result.replaceChildren();message.textContent='正在讀取設定…';dialog.showModal();lock(true);
    try{const data=await request('/api/settings');token=data.token;apply(data);form.hidden=false;message.textContent='金鑰留空會保留原設定；儲存後立即生效。';}
    catch{message.textContent='無法讀取本機 API 設定。請在專案資料夾執行 npm start，再開啟 http://127.0.0.1:4180/#api-settings。';}
    finally{lock(false);}
  }
  form.addEventListener('submit',async event=>{
    event.preventDefault();if(busy)return;lock(true);result.replaceChildren();message.textContent='正在儲存…';
    const payload={deepseekKey:field('settings-deepseek-key').value,tavusKey:field('settings-tavus-key').value,model:field('settings-model').value};
    try{const data=await request('/api/settings',payload);clearSecrets();apply(data);message.textContent=data.message;document.dispatchEvent(new CustomEvent('interview:settings-updated'));}
    catch(error){message.textContent=error.message;}
    finally{lock(false);}
  });
  check.addEventListener('click',async()=>{
    if(busy)return;
    const changed=field('settings-deepseek-key').value||field('settings-tavus-key').value||
      field('settings-model').value!==saved.model;
    if(changed){showCheckStatus('有尚未儲存的變更。請先按「儲存並套用」，再檢查連線。');return;}
    lock(true);
    check.textContent='檢查中…';
    showCheckStatus('正在檢查已儲存的連線，請稍候…');
    try{
      const data=await request('/api/settings/check',{});
      const lines=[['大模型',data.deepseek],['Tavus',data.tavus]].map(([name,item])=>{
        const line=document.createElement('p');
        line.className=item.ok?'settings-ok':'settings-error';
        line.textContent=`${name}：${item.message}`;
        return line;
      });
      document.dispatchEvent(new CustomEvent('interview:settings-updated'));
      result.replaceChildren(...lines);
      result.scrollIntoView({block:'nearest'});
    }catch(error){
      showCheckStatus(error.name==='TimeoutError'?'檢查逾時，請確認本機服務後再試。':error instanceof TypeError?'無法連到本機服務，請確認已啟動真面一下後再試。':error.message);
    }finally{check.textContent=checkLabel;lock(false);}
  });
  document.querySelector('#api-settings-close').addEventListener('click',()=>{if(!busy)dialog.close();});
  dialog.addEventListener('cancel',event=>{if(busy)event.preventDefault();});
  dialog.addEventListener('close',clearSecrets);
  document.querySelectorAll('[data-api-settings]').forEach(button=>button.addEventListener('click',open));
  if(location.hash==='#api-settings')open();
})();
