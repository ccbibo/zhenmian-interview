import test from 'node:test';
import assert from 'node:assert/strict';
import {composeWorker} from '../scripts/compose.mjs';
// Test current source in memory, never a potentially stale checked-in bundle.
const source=await composeWorker();
const worker=(await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'))).default;
const origin='https://opposite-interview-room.foldedpig.chatgpt.site';
const request=(path,body,headers={})=>new Request(origin+path,body===undefined?{headers}:{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(body)});
test('hosted HTML and API assets are served without local installation',async()=>{for(const path of ['/','/app.js','/style.css','/home.js','/home.css']){const r=await worker.fetch(request(path),{});assert.equal(r.status,200);assert.ok((await r.text()).length>100);} });
test('status does not invent configured providers',async()=>{const r=await worker.fetch(request('/api/status'),{}),d=await r.json();assert.equal(d.configured,false);assert.equal(d.llmConfigured,false);assert.equal(d.liveVerified,false);});
test('short session secret is rejected before any potentially billable room',async()=>{const status=await(await worker.fetch(request('/api/status'),{TAVUS_API_KEY:'synthetic',TAVUS_PAL_ID:'p_synthetic',SESSION_SECRET:'short'})).json();assert.equal(status.configured,false);});
test('trial is a real JD summary and explicitly fictitious resume',async()=>{const r=await worker.fetch(request('/api/trial'),{}),d=await r.json();assert.equal(r.status,200);assert.match(d.source.url,/greenhouse/);assert.match(d.notice,/虛構/);assert.match(d.resume,/虛構|虚构/);assert.ok(d.jd.length>100);});
test('analyze returns traceable lexical evidence, never a suitability score',async()=>{const data=await(await worker.fetch(request('/api/trial'),{})).json();const r=await worker.fetch(request('/api/analyze',data),{}),d=await r.json();assert.equal(r.status,200);assert.equal(d.method,'lexical_only');assert.equal(d.jd[0].id,'JD001');assert.ok(d.resume[0].id.startsWith('CV'));assert.equal(d.score,undefined);});
test('external model calls require consent',async()=>{const d=await(await worker.fetch(request('/api/trial'),{})).json();const r=await worker.fetch(request('/api/question',d),{});assert.equal(r.status,400);assert.equal((await r.json()).error,'consent_required');});
test('without API key actual interview cannot be claimed started',async()=>{const d=await(await worker.fetch(request('/api/trial'),{})).json();const r=await worker.fetch(request('/api/question',{...d,consent:true,round:'2',interviewType:'technical'}),{});assert.equal(r.status,503);assert.equal((await r.json()).error,'llm_not_configured');});
test('cross-origin requests are rejected',async()=>{const r=await worker.fetch(request('/api/status',undefined,{Origin:'https://example.org'}),{});assert.equal(r.status,403);});
test('unknown files cannot expose source or secrets',async()=>{for(const path of ['/worker/runtime.mjs','/.env','/server.mjs'])assert.equal((await worker.fetch(request(path),{})).status,404);});
test('report cannot be generated before any candidate answers',async()=>{const d=await(await worker.fetch(request('/api/trial'),{})).json();const r=await worker.fetch(request('/api/report',{...d,consent:true,history:[]}),{});assert.equal(r.status,400);assert.equal((await r.json()).error,'insufficient_answers');});

const syntheticEnv={TAVUS_API_KEY:'synthetic-only',TAVUS_PAL_ID:'p_fixture',SESSION_SECRET:'fixture-only-not-a-real-secret-12345',TAVUS_MAX_CALL_SECONDS:'120'};
const validSession={jd:'AI Application Engineer 熟悉 API、RAG、Python 與部署流程。',resume:'全虛構測試履歷，描述 RAG 原型與 Python API 設計經驗。',roles:[{id:'lin',name:'林以安',role:'HR'}],round:'1',durationMinutes:45,consent:true};
test('hosted status validates provider settings and reports the effective cost cap without a network request',async t=>{
  let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;throw Error('must not contact provider');});
  const status=await(await worker.fetch(request('/api/status'),{...syntheticEnv,LLM_API_KEY:'fixture-only',LLM_MODEL:'deepseek-flash',LLM_BASE_URL:'https://wrong.example'})).json();
  assert.equal(status.configured,true);assert.equal(status.maxCallSeconds,120);assert.equal(status.reportConfigured,false);assert.equal(status.llmConfigurationError,'llm_base_rejected');
  const bad=await(await worker.fetch(request('/api/status'),{...syntheticEnv,TAVUS_MAX_CALL_SECONDS:'bad'})).json();
  assert.equal(bad.configured,false);assert.equal(bad.maxCallSeconds,null);assert.equal(bad.configError,'invalid_call_cap');
  const missing=await(await worker.fetch(request('/api/status'),{...syntheticEnv,TAVUS_PAL_ID:'  '})).json();
  assert.equal(missing.configured,false);assert.deepEqual(missing.missingConfiguration,['TAVUS_PAL_ID']);assert.equal(calls,0);
});
test('hosted create sends exactly 120 seconds despite a 45-minute request and reports actual duration',async t=>{
  const calls=[];t.mock.method(globalThis,'fetch',async(url,options)=>{calls.push({url,body:JSON.parse(options.body)});return new Response(JSON.stringify({conversation_id:'c_fixture',conversation_url:'https://fixture.daily.co/c_fixture',meeting_token:'fixture-token'}));});
  const response=await worker.fetch(request('/api/session',validSession),syntheticEnv),data=await response.json();
  assert.equal(response.status,201);assert.equal(calls.length,1);assert.equal(calls[0].body.properties.max_call_duration,120);assert.equal(calls[0].body.properties.enable_recording,false);
  assert.match(calls[0].body.conversational_context,/面試 2 分鐘/);assert.equal(data.durationMinutes,2);assert.equal(data.liveVerified,false);
});
test('invalid hosted cap stops creation before any external request',async t=>{
  let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;throw Error('must not contact provider');});
  const response=await worker.fetch(request('/api/session',validSession),{...syntheticEnv,TAVUS_MAX_CALL_SECONDS:'0'});
  assert.equal(response.status,503);assert.equal((await response.json()).error,'invalid_call_cap');assert.equal(calls,0);
});
test('invalid hosted face mapping is diagnosed before any external request',async t=>{
  let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;throw Error('must not contact provider');});
  for(const map of ['null','[]','{"lin":3}']){
    const env={...syntheticEnv,TAVUS_FACE_MAP:map};
    const status=await(await worker.fetch(request('/api/status'),env)).json();
    assert.equal(status.configured,false);assert.equal(status.configError,'invalid_face_map');
    const response=await worker.fetch(request('/api/session',validSession),env);
    assert.equal(response.status,503);assert.equal((await response.json()).error,'invalid_face_map');
  }
  assert.equal(calls,0);
});

// Lifecycle fixtures remain synthetic; importing a second module models a fresh
// isolate, not a real cross-region deployment or a persistent distributed lock.
const newIsolate=async()=> (await import('data:text/javascript;base64,'+Buffer.from(source+'\n// '+crypto.randomUUID()).toString('base64'))).default;
const identity={'oai-authenticated-user-id':'fixture-owner'};
const claimCookie=response=>response.headers.get('set-cookie').split(';')[0];
test('encrypted recovery resumes the original room and ended claim permits owner-only transcript reads',async t=>{
 let ended=false,creates=0;
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  if(options.method==='POST'&&url.endsWith('/end')){ended=true;return new Response('{}');}
  if(options.method==='POST'){creates++;return new Response(JSON.stringify({conversation_id:'c_recover',conversation_url:'https://fixture.daily.co/c_recover',meeting_token:'fixture-private-token'}));}
  return new Response(JSON.stringify({conversation_id:'c_recover',status:ended?'ended':'active',events:ended?[{event_type:'application.transcription_ready',properties:{transcript:[{role:'assistant',content:'請介紹專案。'},{role:'user',content:'我用 Python 製作 RAG 原型。'}]}}]:[]}));
 });
 const created=await worker.fetch(request('/api/session',validSession,identity),syntheticEnv),data=await created.json(),cookie=claimCookie(created);
 assert.equal(created.status,201);
 const isolated=await newIsolate();
 const status=await(await isolated.fetch(request('/api/status',undefined,{...identity,Cookie:cookie}),syntheticEnv)).json();
 assert.equal(status.activeSessionId,data.sessionId);assert.equal(status.distributedSessionLock,false);assert.equal(status.conversationUrl,undefined);
 const recovery=await isolated.fetch(request('/api/session/'+data.sessionId,undefined,{...identity,Cookie:cookie}),syntheticEnv),recovered=await recovery.json();
 assert.equal(recovered.conversationUrl,data.conversationUrl);assert.equal(creates,1);
 const duplicate=await isolated.fetch(request('/api/session',validSession,{...identity,Cookie:cookie}),syntheticEnv);assert.equal(duplicate.status,409);assert.equal(creates,1);
 const forbidden=await isolated.fetch(request('/api/session/'+data.sessionId+'/transcript',undefined,{'oai-authenticated-user-id':'other-owner',Cookie:cookie}),syntheticEnv);assert.equal(forbidden.status,404);
 const stopped=await isolated.fetch(request('/api/session/end',{sessionId:data.sessionId},{...identity,Cookie:cookie}),syntheticEnv),endedCookie=claimCookie(stopped);assert.equal(stopped.status,200);
 const finished=await(await isolated.fetch(request('/api/status',undefined,{...identity,Cookie:endedCookie}),syntheticEnv)).json();assert.equal(finished.activeSession,false);assert.equal(finished.lastSessionId,data.sessionId);
 const transcript=await(await isolated.fetch(request('/api/session/'+data.sessionId+'/transcript',undefined,{...identity,Cookie:endedCookie}),syntheticEnv)).json();assert.equal(transcript.state,'ready');assert.equal(transcript.history[1].role,'candidate');assert.equal(transcript.history[1].id,'tavus_0002');
});
test('oversized encrypted join claims trigger cleanup rather than returning an unusable billable room',async t=>{
 let creates=0,ends=0;
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  if(url.endsWith('/end')){ends++;return new Response('{}');}
  creates++;return new Response(JSON.stringify({conversation_id:'c_large',conversation_url:'https://fixture.daily.co/c_large',meeting_token:'x'.repeat(2300)}));
 });
 const response=await worker.fetch(request('/api/session',validSession,identity),syntheticEnv),body=await response.json();
 assert.equal(response.status,502);assert.equal(body.error,'session_cookie_too_large');assert.equal(creates,1);assert.equal(ends,1);assert.equal(body.conversationUrl,undefined);
 const status=await(await worker.fetch(request('/api/status',undefined,{...identity,Cookie:claimCookie(response)}),syntheticEnv)).json();assert.equal(status.activeSession,false);assert.equal(status.state,'ended');
});
test('unknown create outcome survives a new isolate through the claim and is never automatically retried',async t=>{
 let calls=0;t.mock.method(globalThis,'fetch',async()=>{calls++;throw Error('fixture interrupted network');});
 const response=await worker.fetch(request('/api/session',validSession,identity),syntheticEnv),cookie=claimCookie(response);assert.equal(response.status,502);
 const isolated=await newIsolate();
 const status=await(await isolated.fetch(request('/api/status',undefined,{...identity,Cookie:cookie}),syntheticEnv)).json();assert.equal(status.requiresProviderCheck,true);
 const again=await isolated.fetch(request('/api/session',validSession,{...identity,Cookie:cookie}),syntheticEnv);assert.equal(again.status,409);assert.equal(calls,1);
});
test('voice report verifies original document fingerprint and ignores caller-supplied history',async t=>{
 let ended=false,modelCalls=0;
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  if(url.startsWith('https://api.deepseek.com/')){modelCalls++;const body=JSON.parse(options.body);assert.match(body.messages[1].content,/我用 Python 製作 RAG 原型/);assert.doesNotMatch(body.messages[1].content,/FAKE_CANDIDATE/);return new Response(JSON.stringify({choices:[{finish_reason:'stop',message:{content:JSON.stringify({summary:'描述了原型經驗。',feedback:[{turnId:'tavus_0002',observation:'說明使用 Python 建立原型。',improvement:'補充測試方法。',evidenceIds:['JD001','CV001']}],unobserved:['尚未觀察部署流程。']})}}]}));}
  if(url.endsWith('/end')){ended=true;return new Response('{}');}
  if(options.method==='POST')return new Response(JSON.stringify({conversation_id:'c_report',conversation_url:'https://fixture.daily.co/c_report',meeting_token:'fixture-token'}));
  return new Response(JSON.stringify({conversation_id:'c_report',status:ended?'ended':'active',events:[{event_type:'application.transcription_ready',properties:{transcript:[{role:'assistant',content:'請介紹專案。'},{role:'user',content:'我用 Python 製作 RAG 原型。'}]}}]}));
 });
 const env={...syntheticEnv,LLM_API_KEY:'fixture-only',LLM_BASE_URL:'https://api.deepseek.com',LLM_MODEL:'deepseek-flash'};
 const created=await worker.fetch(request('/api/session',validSession,identity),env),data=await created.json(),cookie=claimCookie(created);
 const stopped=await worker.fetch(request('/api/session/end',{sessionId:data.sessionId},{...identity,Cookie:cookie}),env),headers={...identity,Cookie:claimCookie(stopped)};
 const wrong=await worker.fetch(request('/api/session/'+data.sessionId+'/report',{consent:true,jd:validSession.jd+' modified',resume:validSession.resume},headers),env);assert.equal(wrong.status,409);assert.equal((await wrong.json()).error,'documents_changed');assert.equal(modelCalls,0);
 const report=await worker.fetch(request('/api/session/'+data.sessionId+'/report',{consent:true,jd:validSession.jd,resume:validSession.resume,history:[{id:'fake',role:'candidate',content:'FAKE_CANDIDATE'}]},headers),env),result=await report.json();assert.equal(report.status,200);assert.equal(result.source,'tavus_transcript');assert.equal(modelCalls,1);assert.equal(result.feedback[0].turnId,'tavus_0002');
});
test('concurrent requests from one owner cannot create two rooms while document hashing yields',async t=>{
 let calls=0,release;
 const waiting=new Promise(resolve=>{release=resolve;});
 t.mock.method(globalThis,'fetch',async()=>{calls++;await waiting;return new Response(JSON.stringify({conversation_id:'c_once',conversation_url:'https://fixture.daily.co/c_once',meeting_token:'fixture-token'}));});
 const isolated=await newIsolate();
 const responses=Promise.all([isolated.fetch(request('/api/session',validSession,identity),syntheticEnv),isolated.fetch(request('/api/session',validSession,identity),syntheticEnv)]);
 // Allow both async fingerprints to complete before releasing the provider fixture.
 await new Promise(resolve=>setImmediate(resolve));
 await new Promise(resolve=>setImmediate(resolve));
 release();
 const results=await responses;assert.deepEqual(results.map(result=>result.status).sort(),[201,409]);assert.equal(calls,1);
});
test('concurrent voice reports spend one model request and reuse only the matching private transcript version',async t=>{
 let modelCalls=0,version=1,releaseModel,modelEntered;
 const entered=new Promise(resolve=>{modelEntered=resolve;});
 const delayed=new Promise(resolve=>{releaseModel=resolve;});
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  if(url.startsWith('https://api.deepseek.com/')){
   modelCalls++;modelEntered();await delayed;
   return new Response(JSON.stringify({choices:[{finish_reason:'stop',message:{content:JSON.stringify({summary:'描述了原型經驗。',feedback:[{turnId:'tavus_0002',observation:'說明使用 Python 建立原型。',improvement:'補充測試方法。',evidenceIds:['JD001','CV001']}],unobserved:[]})}}]}));
  }
  if(url.endsWith('/end'))return new Response('{}');
  if(options.method==='POST')return new Response(JSON.stringify({conversation_id:'c_report_once',conversation_url:'https://fixture.daily.co/c_report_once',meeting_token:'fixture-token'}));
  return new Response(JSON.stringify({conversation_id:'c_report_once',status:'ended',events:[{event_type:'application.transcription_ready',properties:{transcript:[{role:'assistant',content:'請介紹專案。'},{role:'user',content:'我用 Python 製作 RAG 原型。版本'+version}]}}]}));
 });
 const isolated=await newIsolate(),env={...syntheticEnv,LLM_API_KEY:'fixture-only',LLM_BASE_URL:'https://api.deepseek.com',LLM_MODEL:'deepseek-flash'};
 const created=await isolated.fetch(request('/api/session',validSession,identity),env),data=await created.json(),cookie=claimCookie(created);
 const stopped=await isolated.fetch(request('/api/session/end',{sessionId:data.sessionId},{...identity,Cookie:cookie}),env),headers={...identity,Cookie:claimCookie(stopped)};
 const body={consent:true,jd:validSession.jd,resume:validSession.resume},path='/api/session/'+data.sessionId+'/report';
 const first=isolated.fetch(request(path,body,headers),env);await entered;
 const simultaneous=await isolated.fetch(request(path,body,headers),env);assert.equal(simultaneous.status,409);assert.equal((await simultaneous.json()).error,'report_in_progress');assert.equal(modelCalls,1);
 releaseModel();const initial=await first;assert.equal(initial.status,200);assert.equal((await initial.json()).cached,false);
 const cached=await isolated.fetch(request(path,body,headers),env);assert.equal(cached.status,200);assert.equal((await cached.json()).cached,true);assert.equal(modelCalls,1);
 const forbidden=await isolated.fetch(request(path,body,{...headers,'oai-authenticated-user-id':'different-owner'}),env);assert.equal(forbidden.status,404);assert.equal(modelCalls,1);
 version=2;const revised=await isolated.fetch(request(path,body,headers),env);assert.equal(revised.status,200);assert.equal((await revised.json()).cached,false);assert.equal(modelCalls,2);
});
test('three manually started rounds carry only verified final transcripts with the same documents and owner',async t=>{
 const payloads=[],ended=new Set();let creates=0;
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  const match=url.match(/\/conversations\/(c_round_\d+)/),id=match?.[1];
  if(url.endsWith('/end')){ended.add(id);return new Response('{}');}
  if(options.method==='POST'){const body=JSON.parse(options.body);payloads.push(body);creates++;return new Response(JSON.stringify({conversation_id:'c_round_'+creates,conversation_url:'https://fixture.daily.co/c_round_'+creates,meeting_token:'fixture-token'}));}
  const round=Number(id.split('_').at(-1));return new Response(JSON.stringify({conversation_id:id,status:ended.has(id)?'ended':'active',events:[{event_type:'application.transcription_ready',properties:{transcript:[{role:'assistant',content:'請說明你的專案。'},{role:'user',content:round===1?'ROUND_ONE_ACTUAL 用 Python 建立 RAG。':'ROUND_TWO_ACTUAL 說明評估取捨。'}]}}]}));
 });
 const isolated=await newIsolate();let headers={...identity},receipt,firstReceiptExpiry;
 for(let round=1;round<=3;round++){
  const response=await isolated.fetch(request('/api/session',{...validSession,round:String(round),history:[{role:'candidate',content:'FAKE_CLIENT_HISTORY'}],...(receipt?{continuation:{receipt}}:{})},headers),syntheticEnv),created=await response.json();
  assert.equal(response.status,201,JSON.stringify(created));assert.equal(creates,round);assert.equal(created.durationMinutes,2);assert.equal(created.continuationUsed,round>1);assert.equal(created.priorRoundCount,round-1);headers={...identity,Cookie:claimCookie(response)};
  assert.equal(payloads[round-1].properties.max_call_duration,120);assert.doesNotMatch(payloads[round-1].conversational_context,/FAKE_CLIENT_HISTORY/);
  if(round>1)assert.match(payloads[round-1].conversational_context,/ROUND_ONE_ACTUAL/);
  if(round===3)assert.match(payloads[round-1].conversational_context,/ROUND_TWO_ACTUAL/);
  const stop=await isolated.fetch(request('/api/session/end',{sessionId:created.sessionId},headers),syntheticEnv);assert.equal(stop.status,200);headers={...identity,Cookie:claimCookie(stop)};
  const next=await isolated.fetch(request('/api/session/'+created.sessionId+'/continuation',{},headers),syntheticEnv),issued=await next.json();
  if(round<3){assert.equal(next.status,200,JSON.stringify(issued));assert.equal(issued.nextRound,String(round+1));assert.equal(typeof issued.receipt,'string');assert.equal(issued.lineage,undefined);assert.equal(issued.history,undefined);receipt=issued.receipt;if(round===1)firstReceiptExpiry=issued.expiresAt;else assert.equal(issued.expiresAt,firstReceiptExpiry,'continuation cannot extend the original source deadline');assert.equal(creates,round);}
  else assert.ok(next.status>=400,'round three cannot issue a fourth round');
 }
});
test('continuation rejects changed documents, wrong owner, tampering and changed provider transcript before creating a room',async t=>{
 let creates=0,altered=false;
 t.mock.method(globalThis,'fetch',async(url,options)=>{
  if(url.endsWith('/end'))return new Response('{}');
  if(options.method==='POST'){creates++;return new Response(JSON.stringify({conversation_id:'c_signed',conversation_url:'https://fixture.daily.co/c_signed',meeting_token:'fixture-token'}));}
  return new Response(JSON.stringify({conversation_id:'c_signed',status:'ended',events:[{event_type:'application.transcription_ready',properties:{transcript:[{role:'user',content:altered?'Changed provider transcript':'Original actual candidate answer'}]}}]}));
 });
 const isolated=await newIsolate();
 const response=await isolated.fetch(request('/api/session',validSession,identity),syntheticEnv),created=await response.json();
 const stop=await isolated.fetch(request('/api/session/end',{sessionId:created.sessionId},{...identity,Cookie:claimCookie(response)}),syntheticEnv),headers={...identity,Cookie:claimCookie(stop)};
 const issuedResponse=await isolated.fetch(request('/api/session/'+created.sessionId+'/continuation',{},headers),syntheticEnv),issued=await issuedResponse.json();assert.equal(issuedResponse.status,200,JSON.stringify(issued));
 for(const [body,ownerHeaders] of [
  [{...validSession,round:'2',resume:validSession.resume+' changed',continuation:{receipt:issued.receipt}},headers],
  [{...validSession,round:'2',continuation:{receipt:issued.receipt}},{'oai-authenticated-user-id':'different-owner'}],
  [{...validSession,round:'2',continuation:{receipt:issued.receipt.slice(0,-2)+'xx'}},headers]
 ]){const blocked=await isolated.fetch(request('/api/session',body,ownerHeaders),syntheticEnv);assert.ok(blocked.status>=400);assert.equal(creates,1);}
 altered=true;const changed=await isolated.fetch(request('/api/session',{...validSession,round:'2',continuation:{receipt:issued.receipt}},headers),syntheticEnv);assert.ok(changed.status>=400);assert.equal(creates,1);
 altered=false;t.mock.method(Date,'now',()=>issued.expiresAt+1);
 const expired=await isolated.fetch(request('/api/session',{...validSession,round:'2',continuation:{receipt:issued.receipt}},identity),syntheticEnv);assert.equal(expired.status,410);assert.equal((await expired.json()).error,'continuation_expired');assert.equal(creates,1);
});

test('hosted default preserves selected duration in provider settings and response',async t=>{
  const calls=[];
  t.mock.method(globalThis,'fetch',async(url,options)=>{
    calls.push(JSON.parse(options.body));
    return new Response(JSON.stringify({conversation_id:'c_duration',conversation_url:'https://fixture.daily.co/c_duration',meeting_token:'fixture-token'}));
  });
  const {TAVUS_MAX_CALL_SECONDS:ignored,...normalEnv}=syntheticEnv;
  const status=await(await worker.fetch(request('/api/status'),normalEnv)).json();
  assert.equal(status.maxCallSeconds,2700);
  for(const minutes of [15,20,25,30,35,40,45]) {
    const response=await worker.fetch(request('/api/session',{...validSession,durationMinutes:minutes}),normalEnv);
    assert.equal(response.status,201);
    assert.equal((await response.json()).durationMinutes,minutes);
    assert.equal(calls.at(-1).properties.max_call_duration,minutes*60);
    assert.ok(calls.at(-1).conversational_context.includes(`面試 ${minutes} 分鐘`));
  }
});
