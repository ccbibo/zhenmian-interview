# 真面一下｜Vercel 私人試驗部署包

這是與現有 Worker 共用同份後端的部署轉接層，可重建的部署來源包。原 Sites 專案身份與秘密設定保留；本包不含任何秘密值。

1. 在 Vercel Drop 上傳本目錄的 ZIP 並選擇自己的帳戶，不升級或購買方案。
2. **在加入 API 金鑰前**，於 Security → Deployment Protection 啟用 Vercel Authentication，範圍選 All Deployments；確認正式網址也要求有權限的帳戶登入。不得建立公開例外或分享繞過連結。
3. 將 LLM_API_KEY、LLM_BASE_URL、LLM_MODEL、TAVUS_API_KEY、TAVUS_PAL_ID、SESSION_SECRET、TAVUS_MAX_CALL_SECONDS 設為伺服器端秘密。Secrets 不會從 Sites 自動轉移，不可從公開前端讀取或把值寫入本包。
4. 只有確認所有部署都已受保護，才設定 APP_PRIVATE_HOST_CONFIRMED=true 並重新部署。此開關本身不是身份驗證；真實身份保護由 Vercel Authentication 執行。
5. 檢查自家網址的 status、準備與單人短場流程。實際通話依使用者選擇的 15–45 分鐘；正常環境設定 `TAVUS_MAX_CALL_SECONDS=2700`，舊環境的 `120` 也須更新並重新部署；任何建立不明結果都不要自動重開。

未確認私人主機時，模型與通話 API 預設拒絕所有操作，即使已誤填金鑰也不能建立通話。轉接層不信任訪客自傳的 Sites 身份標頭。

這仍是單人試驗架構；Vercel 多實例與 Worker isolate 一樣，沒有跨節點持久防重保證。不可因此宣稱公開多使用者已完成，完整產品驗收應以實際測試結果為準。

官方依據（2026-11-01查閱）：
- https://vercel.com/i/deploy-to-vercel-without-git
- https://vercel.com/docs/functions/runtimes/node-js
- https://vercel.com/changelog/protect-production-deployments-for-free-on-every-plan

本地由 `node scripts/package-vercel.mjs` 更新 Worker，依原碼產生，不手改 worker.mjs。

轉接函式最長120秒，為核驗前兩輪逐字稿與建立請求保留完成時間；這是單次 HTTP 請求上限，與整場面試時長不同。面試通話由影音服務維持，實際長度依使用者選擇的 15–45 分鐘及伺服器上限設定。
